<!doctype html>

<html lang="en">
<head>
  <meta charset="utf-8">

  <title>Contact Freebie</title>
  <meta name="description" content="This is description of your business, make sure that you change it to something SEO friendly.">
  <meta name="author" content="Web Design Stories">
<meta name="keywords" content="meta tags,search engine optimization" />
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <link rel="stylesheet" href="css/main.css">

  <!--[if lt IE 9]>
  <script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script>
  <![endif]-->

</head>

<body>
  
<div class="navbar navbar-fixed-top">
              <div class="navbar-inner">
                <div class="container">
                  <a class="btn btn-navbar" data-toggle="collapse" data-target=".navbar-responsive-collapse">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                  </a>
                  <a class="brand" href="index.html">Freebie</a>
                  <div class="nav-collapse collapse navbar-responsive-collapse">
                    <ul class="nav">
                      <li><a href="index.html">Home</a></li>
                      <li><a href="about.html">About</a></li>
                      <li><a href="index.html">Services</a></li>
                     
                    </ul>
                  
                    <ul class="nav pull-right">
                      <li><a href="index.html">FAQ</a></li>
                      <li class="divider-vertical"></li>
                     <li class="active"><a href="contact.php">Contact</a></li>
                    </ul>
                  </div><!-- /.nav-collapse -->
                </div>
              </div><!-- /navbar-inner -->
            </div>
<div class="container top-div">

<div class="row-fluid margin-top-50">
	
		<div class="row-fluid min-height-300">
				<div class="span12 text-center">
<?php


if(!ISSET($_POST["name"], $_POST["email"], $_POST["phone"], $_POST["message"])){

		echo 

		'<h3>Contact Freebie</h3>

<p>Give us a quick mail and we\'ll get in touch with you in no time!</p>
<hr />

<form method="POST" action="contact.php">

	<input type="text" name="name" class="input-xxlarge" placeholder="Full name..">
		<input type="text" name="phone" class="input-xxlarge" placeholder="Phone number..">
		<input type="text" name="email" class="input-xxlarge" placeholder="Email address..">
		<hr />
			<label for="find"><p>How did you find us? </p></label>
			<select name="find">
			<option></option>
			<option>Search Engine</option>
			<option>Newspaper</option>
			<option>Friend</option>
			<option>Advert</option>
			</select>
			<hr />
			<textarea name="message" rows="10" style="width:100%;" placeholder="Your message.."></textarea>
			<input type="text" name="address" style="display:none"><p style="display:none;">Humans should not see this field, if you do.. Please leave it blank.</p>
			' . "<br />" . '<input type="submit" name="submit" class="btn btn-success" value="Send Message">
</form>';
	}
				

	

	if($_SERVER["REQUEST_METHOD"] == "POST"){

		$name = trim($_POST["name"]);
		$email = trim($_POST["email"]);
		$phone = trim($_POST["phone"]);
		$message = trim($_POST["message"]);
		$find = trim($_POST["find"]);
		$address = trim($_POST["address"]);
			if($address !== ""){
				echo "There was problem with your form, please contact admin of this website.";
				exit();
			}

			if($name == "" OR $phone == "" OR $phone == "" OR $message == ""){

				echo '
<div class="alert alert-error">
 Please fill in all required fields
</div>

				<form method="POST" action="contact.php">

	<input type="text" name="name" class="input-xxlarge" placeholder="Full name.." value="' . $name . '">
		<input type="text" name="phone" class="input-xxlarge" placeholder="Phone number.." value="' . $phone . '">
		<input type="text" name="email" class="input-xxlarge" placeholder="Email address.." value="' . $email . '">
		<hr />
			<label for="find"><p>How did you find us? </p></label>
			<select name="find">
			<option></option>
			<option>Search Engine</option>
			<option>Newspaper</option>
			<option>Friend</option>
			<option>Advert</option>
			</select>
			<hr />
			<textarea name="message" rows="10" style="width:100%;" placeholder="Your message.." value="' . $message . '"></textarea>
			<input type="text" name="address" style="display:none"><p style="display:none;">Humans should not see this field, if you do.. Please leave it blank.</p>
			' . "<br />" . '<input type="submit" name="submit" class="btn btn-success" value="Send Message">
</form>';
			}

			else{
				
	foreach ($_POST as $value) {
			if(stripos($value, 'Content-type:') !== FALSE){
				echo "There was a problem with information you entered. Please contact administrator for help.";
				exit;
			}
		}

$from = $email;
$headers = "MIME-Version: 1.0" . "\r\n";
$headers .= "Content-type:text/html;charset=iso-8859-1" . "\r\n";
$headers .= 'From: ' . $from . "\r\n";
$to = "ENTER YOUR EMAIL ADDRESS";
$subject = "Mail from website!";
$body = "You have received mail from: <b>" . $name . "</b>" . "<br>". "Tel Number: " . "<b>" . $phone . "</b>" . "<br><br>". "This is the message: " . "<br>" . $message . "<br><br>" . "<b>" . "Found your website by: " . $find . "</b>";
mail($to,$subject,$body,$headers);
 echo '

 <div class="alert alert-success">
 Your message has been sent. Thank you!
</div>
<p>Where would you like to go now?</p>
<hr />
<div class="row-fluid">
	<div class="span6 text-center"><a href="index.html" class="btn btn-primary btn-large">Back Home</a></div>
	<div class="span6 text-center"><a href="contact.php" class="btn btn-success btn-large">Another Mail</a></div>
</div>

 ';



			
			}


	}
	
?>
</div>

		</div>
</div>
</div>



<section class="margin-top-50">
  <div class="row-fluid footer">
   <footer>
    <div class="span4">

<address>
  <strong>Freebie Ltd</strong><br>
  Your address<br>
  Your city and postcode<br>
  <abbr title="Phone">P:</abbr> (123) 456-789
</address>
 
<address>
  <strong>Full Name</strong><br>
  <a href="#">first.last@example.com</a>
</address>
    </div>
    <div class="span4 text-center">Freebie &copy; 2014<br /><small><a href="http://www.webdesignstories.com" class="muted-more">Developed By Web Design Stories</a></small></div>
    <div class="span1 pull-right">
      <ul class="unstyled">
          <p><small>SITEMAP</small></p>
        <li><a href="index.html">Home</a></li>
        <li><a href="about.html">About</a></li>
        <li><a href="index.html">Services</a></li>
      </ul>

    </div>
   </footer>
 </div>
</section>


  <script type="text/javascript" src="js/jquery.js"></script>
<script type="text/javascript" src="js/bootstrap.min.js"></script>

<!-- Modal -->
<div id="myModal" class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-header">
    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
    <h3 id="myModalLabel">Get in touch</h3>
  </div>
  <div class="modal-body">
    <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad</p>
  </div>
  <div class="modal-footer">
    <button class="btn" data-dismiss="modal" aria-hidden="true">Close</button>
    <button class="btn btn-primary">Save changes</button>
  </div>
</div>

<script type="text/javascript">
$('a').hover(function(){
  $(this).tooltip('show');
});
</script>


</body>
</html>




