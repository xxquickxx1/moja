# Read about factories at https://github.com/thoughtbot/factory_girl

FactoryGirl.define do
  factory :portfolio do
    url "MyString"
    name "MyString"
    category "MyString"
    description "MyText"
  end
end
