# Read about factories at https://github.com/thoughtbot/factory_girl

FactoryGirl.define do
  factory :website do
    design "MyString"
    logo "MyString"
    pages "MyString"
    images "MyString"
    content "MyString"
    features "MyString"
    socialmedia "MyString"
  end
end
