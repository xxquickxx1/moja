# Read about factories at https://github.com/thoughtbot/factory_girl

FactoryGirl.define do
  factory :testimonial do
    name "MyString"
    website "MyString"
    description "MyText"
  end
end
