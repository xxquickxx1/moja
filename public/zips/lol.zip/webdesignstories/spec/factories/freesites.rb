# Read about factories at https://github.com/thoughtbot/factory_girl

FactoryGirl.define do
  factory :freesite do
    name "MyString"
    description "MyText"
    freeby_id nil
  end
end
