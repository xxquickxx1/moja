require 'spec_helper'

describe ChargesController do

end
