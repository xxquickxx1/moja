require 'spec_helper'

describe FreesitesController do

end
