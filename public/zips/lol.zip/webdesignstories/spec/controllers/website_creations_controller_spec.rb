require 'spec_helper'

describe WebsiteCreationsController do

end
