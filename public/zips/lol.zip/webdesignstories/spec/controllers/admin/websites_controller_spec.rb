require 'spec_helper'

describe Admin::WebsitesController do

end
