require 'spec_helper'

describe Usersite do
  pending "add some examples to (or delete) #{__FILE__}"
end
