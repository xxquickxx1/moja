# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Webdesignstories::Application.config.secret_token = 'f7b649f7797a717b17662792eae74e28597f5b95cb417a71f39be98d05be18e5bb05caec421f3cb39807a5950336bf4c41eb0e7d3b0ff75b70b9683df1a2fa22'
