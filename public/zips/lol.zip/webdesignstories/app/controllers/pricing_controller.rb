class PricingController < ApplicationController
  def home
  end
end
