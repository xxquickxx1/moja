class PrivacyController < ApplicationController
  def privacy
  	@pageTitle = "Privacy | Web Design Stories"
  end
end
