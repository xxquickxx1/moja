class SitemapController < ApplicationController
	layout nil
  def sitemap
  	
  end
end
