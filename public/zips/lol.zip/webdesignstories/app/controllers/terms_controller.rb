class TermsController < ApplicationController
  def terms
  	@pageTitle = "Terms & Conditions | Web Design Stories"
  end
end
