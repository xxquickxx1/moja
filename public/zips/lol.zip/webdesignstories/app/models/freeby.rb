class Freeby < ActiveRecord::Base
	has_many :freesites
end
