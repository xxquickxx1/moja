class Website < ActiveRecord::Base

end
